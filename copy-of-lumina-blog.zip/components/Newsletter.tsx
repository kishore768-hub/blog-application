
import React from 'react';
import { ArrowRightIcon } from './Icons';

const Newsletter: React.FC = () => {
  return (
    <section className="py-20 px-6">
      <div className="max-w-5xl mx-auto bg-indigo-600 rounded-[3rem] p-10 md:p-16 relative overflow-hidden shadow-2xl shadow-indigo-200">
        {/* Abstract background blobs */}
        <div className="absolute -top-20 -right-20 w-64 h-64 bg-indigo-500 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-indigo-400 rounded-full opacity-30 blur-3xl"></div>

        <div className="relative z-10 flex flex-col items-center text-center">
          <span className="text-indigo-100 text-xs font-bold uppercase tracking-[0.2em] mb-4">Weekly Insights</span>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6 max-w-2xl leading-tight">
            Curated ideas for the modern thinker. Delivered to your inbox.
          </h2>
          <p className="text-indigo-100 md:text-lg mb-10 max-w-xl opacity-90">
            Join 20,000+ readers who receive our weekly digest on design, technology, and productivity. No spam, ever.
          </p>
          
          <form className="w-full max-w-md flex flex-col sm:flex-row gap-4">
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="flex-grow px-6 py-4 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-indigo-200 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all backdrop-blur-sm"
              required
            />
            <button className="bg-white text-indigo-600 px-8 py-4 rounded-2xl font-bold flex items-center justify-center hover:bg-slate-50 transition-colors shadow-lg group">
              Subscribe
              <span className="ml-2 group-hover:translate-x-1 transition-transform">
                <ArrowRightIcon />
              </span>
            </button>
          </form>
          <p className="mt-6 text-indigo-200 text-xs font-medium">
            We value your privacy. Unsubscribe at any time.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
