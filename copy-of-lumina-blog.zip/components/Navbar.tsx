
import React, { useState } from 'react';
import { SearchIcon, MenuIcon } from './Icons';
import { CATEGORIES } from '../data';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/80 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-6'
    }`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">L</span>
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900">Lumina</span>
        </div>

        {/* Desktop Categories */}
        <div className="hidden md:flex items-center space-x-8">
          {CATEGORIES.slice(0, 4).map((cat) => (
            <a 
              key={cat.id} 
              href={`#/category/${cat.slug}`}
              className="text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors"
            >
              {cat.name}
            </a>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-5">
          <button className="p-2 text-slate-600 hover:text-indigo-600 transition-colors">
            <SearchIcon />
          </button>
          <div className="hidden sm:block h-6 w-[1px] bg-slate-200"></div>
          <button className="hidden sm:block text-sm font-semibold text-slate-900 hover:text-indigo-600 transition-colors">
            Sign In
          </button>
          <button className="bg-slate-900 text-white px-5 py-2 rounded-full text-sm font-semibold hover:bg-indigo-600 transition-all shadow-md">
            Get Started
          </button>
          <button className="md:hidden p-2 text-slate-600">
            <MenuIcon />
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
