
import React from 'react';
import { Post } from '../types';

interface CardProps {
  post: Post;
  variant?: 'large' | 'grid';
}

export const ArticleCard: React.FC<CardProps> = ({ post, variant = 'grid' }) => {
  if (variant === 'large') {
    return (
      <article className="group relative bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 flex flex-col lg:flex-row h-full border border-slate-100">
        <div className="lg:w-1/2 overflow-hidden h-64 lg:h-auto">
          <img 
            src={post.image} 
            alt={post.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        </div>
        <div className="lg:w-1/2 p-8 lg:p-12 flex flex-col justify-center">
          <div className="flex items-center space-x-3 mb-6">
            <span className="px-3 py-1 bg-indigo-50 text-indigo-600 text-xs font-bold rounded-full uppercase tracking-wider">
              {post.category}
            </span>
            <span className="text-slate-400 text-xs">•</span>
            <span className="text-slate-500 text-xs font-medium">{post.readTime}</span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-serif font-bold text-slate-900 mb-4 leading-tight group-hover:text-indigo-600 transition-colors">
            {post.title}
          </h2>
          <p className="text-slate-600 text-lg mb-8 line-clamp-3 leading-relaxed">
            {post.excerpt}
          </p>
          <div className="flex items-center mt-auto pt-6 border-t border-slate-50">
            <img src={post.author.avatar} alt={post.author.name} className="w-10 h-10 rounded-full mr-4 object-cover" />
            <div>
              <p className="text-sm font-bold text-slate-900">{post.author.name}</p>
              <p className="text-xs text-slate-500">{post.author.role}</p>
            </div>
          </div>
        </div>
      </article>
    );
  }

  return (
    <article className="group flex flex-col h-full bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300">
      <div className="h-56 overflow-hidden relative">
        <img 
          src={post.image} 
          alt={post.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-indigo-600 text-[10px] font-bold rounded-full uppercase tracking-widest shadow-sm">
            {post.category}
          </span>
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-serif font-bold text-slate-900 mb-3 line-clamp-2 leading-tight group-hover:text-indigo-600 transition-colors">
          {post.title}
        </h3>
        <p className="text-slate-600 text-sm mb-6 line-clamp-2 leading-relaxed flex-grow">
          {post.excerpt}
        </p>
        <div className="flex items-center justify-between pt-4 border-t border-slate-50">
          <div className="flex items-center">
            <img src={post.author.avatar} alt={post.author.name} className="w-8 h-8 rounded-full mr-3 border-2 border-slate-50" />
            <span className="text-xs font-semibold text-slate-900">{post.author.name}</span>
          </div>
          <span className="text-[10px] font-medium text-slate-400 uppercase tracking-tighter">
            {post.date}
          </span>
        </div>
      </div>
    </article>
  );
};
