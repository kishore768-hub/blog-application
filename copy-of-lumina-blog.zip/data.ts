
import { Post, Category } from './types';

export const CATEGORIES: Category[] = [
  { id: '1', name: 'Design', slug: 'design' },
  { id: '2', name: 'Technology', slug: 'technology' },
  { id: '3', name: 'Psychology', slug: 'psychology' },
  { id: '4', name: 'Productivity', slug: 'productivity' },
  { id: '5', name: 'Life', slug: 'life' },
];

export const POSTS: Post[] = [
  {
    id: '1',
    title: 'The Silent Evolution of Minimalist Architecture',
    excerpt: 'How the concept of "less is more" is redefining modern living spaces and urban planning in 2024.',
    content: 'Long form content here...',
    image: 'https://picsum.photos/id/10/1200/800',
    category: 'Design',
    author: {
      name: 'Elena Vance',
      avatar: 'https://i.pravatar.cc/150?u=elena',
      role: 'Design Critic'
    },
    date: 'Oct 12, 2024',
    readTime: '6 min read',
    featured: true,
  },
  {
    id: '2',
    title: 'Deep Work: Reclaiming Focus in the Age of Distraction',
    excerpt: 'Practical strategies for achieving states of flow and maintaining cognitive endurance.',
    content: 'Content...',
    image: 'https://picsum.photos/id/20/800/600',
    category: 'Productivity',
    author: {
      name: 'Marcus Thorne',
      avatar: 'https://i.pravatar.cc/150?u=marcus',
      role: 'Staff Writer'
    },
    date: 'Oct 10, 2024',
    readTime: '8 min read',
  },
  {
    id: '3',
    title: 'The Psychology of Choice: Why Less is Often More',
    excerpt: 'Exploring the paradox of choice and how it influences our daily decision-making process.',
    content: 'Content...',
    image: 'https://picsum.photos/id/48/800/600',
    category: 'Psychology',
    author: {
      name: 'Sarah Chen',
      avatar: 'https://i.pravatar.cc/150?u=sarah',
      role: 'Behavioral Scientist'
    },
    date: 'Oct 8, 2024',
    readTime: '5 min read',
  },
  {
    id: '4',
    title: 'Will Artificial Intelligence Ever Truly Understand Emotion?',
    excerpt: 'Investigating the intersection of neural networks and emotional intelligence.',
    content: 'Content...',
    image: 'https://picsum.photos/id/60/800/600',
    category: 'Technology',
    author: {
      name: 'David Aris',
      avatar: 'https://i.pravatar.cc/150?u=david',
      role: 'Tech Lead'
    },
    date: 'Oct 5, 2024',
    readTime: '12 min read',
  },
  {
    id: '5',
    title: 'Morning Rituals of the Most Creative Minds',
    excerpt: 'From Kafka to Jobs, discover the unique habits that fuel creative genius.',
    content: 'Content...',
    image: 'https://picsum.photos/id/30/800/600',
    category: 'Life',
    author: {
      name: 'Isabella Ross',
      avatar: 'https://i.pravatar.cc/150?u=isabella',
      role: 'Lifestyle Editor'
    },
    date: 'Oct 3, 2024',
    readTime: '4 min read',
  },
  {
    id: '6',
    title: 'The Future of Remote Collaboration',
    excerpt: 'Beyond Zoom: How VR and async tools are shaping the next decade of work.',
    content: 'Content...',
    image: 'https://picsum.photos/id/42/800/600',
    category: 'Technology',
    author: {
      name: 'Marcus Thorne',
      avatar: 'https://i.pravatar.cc/150?u=marcus',
      role: 'Staff Writer'
    },
    date: 'Sep 30, 2024',
    readTime: '7 min read',
  }
];
