
import React from 'react';
import { CATEGORIES, POSTS } from '../data';
import { ArticleCard } from '../components/ArticleCard';
import Newsletter from '../components/Newsletter';

const Home: React.FC = () => {
  const featuredPost = POSTS.find(p => p.featured) || POSTS[0];
  const gridPosts = POSTS.filter(p => p.id !== featuredPost.id);

  return (
    <main className="pt-32 pb-16">
      {/* Hero Header */}
      <section className="max-w-7xl mx-auto px-6 mb-16 text-center">
        <div className="inline-block px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-full text-xs font-bold uppercase tracking-widest mb-6 border border-indigo-100/50">
          The Journal
        </div>
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-slate-900 mb-8 tracking-tight leading-[0.95]">
          Curated Stories for <br className="hidden md:block" />
          <span className="italic text-indigo-600">Thoughtful</span> Readers
        </h1>
        <p className="max-w-2xl mx-auto text-slate-500 text-lg md:text-xl leading-relaxed">
          Explore deep dives into minimalist design, high-performance habits, and the future of creative technology.
        </p>
      </section>

      {/* Categories Bar */}
      <div className="max-w-7xl mx-auto px-6 mb-16">
        <div className="flex items-center justify-center space-x-3 md:space-x-6 overflow-x-auto pb-4 no-scrollbar">
          <button className="whitespace-now8 bg-slate-900 text-white px-6 py-2.5 rounded-full text-sm font-bold shadow-lg shadow-slate-200">
            All Stories
          </button>
          {CATEGORIES.map(cat => (
            <button 
              key={cat.id} 
              className="whitespace-nowrap px-6 py-2.5 bg-white text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-100 rounded-full text-sm font-bold transition-all"
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Section */}
      <section className="max-w-7xl mx-auto px-6 mb-24">
        <ArticleCard post={featuredPost} variant="large" />
      </section>

      {/* Grid Content */}
      <section className="max-w-7xl mx-auto px-6 mb-24">
        <div className="flex items-center justify-between mb-12">
          <div className="flex items-center space-x-4">
            <h2 className="text-3xl font-serif font-bold text-slate-900">Latest Articles</h2>
            <div className="h-[2px] w-24 bg-indigo-100 hidden sm:block"></div>
          </div>
          <a href="#" className="text-sm font-bold text-indigo-600 hover:text-indigo-800 transition-colors flex items-center group">
            View Archive
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {gridPosts.map(post => (
            <ArticleCard key={post.id} post={post} variant="grid" />
          ))}
        </div>
      </section>

      {/* Secondary Featured Section - Small Grid */}
      <section className="max-w-7xl mx-auto px-6 mb-24 bg-slate-50/50 rounded-[3rem] p-12 border border-slate-100">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-4">
            <h3 className="text-3xl font-serif font-bold text-slate-900 mb-6">Trending Topics</h3>
            <p className="text-slate-500 mb-8 leading-relaxed">What our community is reading most this week. Insights that spark conversation.</p>
            <div className="space-y-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="flex items-start group cursor-pointer">
                  <span className="text-3xl font-serif font-bold text-indigo-100 mr-6 group-hover:text-indigo-200 transition-colors">0{i}</span>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1 group-hover:text-indigo-600 transition-colors">Modern Aesthetics in Software Design</h4>
                    <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">4 min read • Design</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="lg:col-span-8">
            <div className="relative group overflow-hidden rounded-[2rem] shadow-xl">
               <img src="https://picsum.photos/id/43/1200/600" className="w-full h-[400px] object-cover transition-transform duration-700 group-hover:scale-105" alt="Promotion" />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent flex flex-col justify-end p-10">
                  <span className="text-white/80 text-xs font-bold uppercase tracking-widest mb-2">Staff Pick</span>
                  <h3 className="text-white text-3xl font-serif font-bold mb-4 max-w-lg">The Architecture of Stillness: Finding Peace in Busy Cities</h3>
                  <button className="text-white font-bold flex items-center group/btn">
                    Read Story
                    <div className="ml-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover/btn:bg-white group-hover/btn:text-slate-900 transition-all">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7-7 7" />
                      </svg>
                    </div>
                  </button>
               </div>
            </div>
          </div>
        </div>
      </section>

      <Newsletter />
    </main>
  );
};

export default Home;
